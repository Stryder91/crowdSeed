### Reflexion and TODO 
fix import for TS version all require mongoose

Forcer le model sur l'interface

### WARNING

- Always declare a collection in lowercase with 's' at the end!!

example : 'products'.

- To know if mongoose connection is fine
console.log(mongoose.connection.readyState);
0: disconnected
1: connected
2: connecting
3: disconnecting



